package mk.com.findsellgive.listeners;

import android.location.Location;

/**
 * Created by Damjan on 09.9.2019
 * Project: find-sell-give
 **/
public interface OnLocationFetchListener {
    void onLocationFetch(Location location);
}
