package mk.com.findsellgive.listeners;

import mk.com.findsellgive.models.Product;


public interface OnProductItemClickListener {
    void onItemClick(Product product);
}
