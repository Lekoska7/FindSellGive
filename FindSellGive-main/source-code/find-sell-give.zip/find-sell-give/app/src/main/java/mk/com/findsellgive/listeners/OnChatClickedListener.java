package mk.com.findsellgive.listeners;

import mk.com.findsellgive.models.Chat;


public interface OnChatClickedListener {
    void onChatClicked(Chat chat);
}
