package mk.com.findsellgive.listeners;

/**
 * Created by Damjan on 08.9.2019
 * Project: find-sell-give
 **/
public interface PermissionGrantedListener {
    void onPermissionGranted();
}
