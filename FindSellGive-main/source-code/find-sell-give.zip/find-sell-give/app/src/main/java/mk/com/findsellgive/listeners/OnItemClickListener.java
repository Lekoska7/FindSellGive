package mk.com.findsellgive.listeners;

import mk.com.findsellgive.models.WishListPost;


public interface OnItemClickListener {
     void onItemClick(WishListPost post);
}
